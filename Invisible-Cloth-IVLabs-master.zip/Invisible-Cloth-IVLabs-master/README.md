# Invisible-Cloth-IVLabs
The Idea of the project is to write a code which detects the color and replaces it with the background.
The first While loop is basically to record the background and further,when the video recording appears on the screen,without moving the camera,be seated infront of camera and take a blue cloth and put it on your body
the blue color in the video is replaced by the background part
